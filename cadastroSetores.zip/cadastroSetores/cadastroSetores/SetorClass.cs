﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace cadastroSetores
{
    class SetorClass
    {
        //Atributos
        private int id;
        private string nome;

        //Métodos Get e Set
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        //Método de Inserir Setor
        public bool InserirSetor()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new ConexaoBDClass().Conectar())
                {
                    string inserir = "insert into setores (nome) values (@nome);";

                    MySqlCommand comando = new MySqlCommand(inserir, conexaoBanco);
                    comando.Parameters.AddWithValue("@nome", Nome);

                    int resultado = comando.ExecuteNonQuery();
                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao inserir setor ", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        //Método de Atualizar Setor
        public bool AtualizarSetor()
        {
            if (id <= 0)
            {
                MessageBox.Show("ID do setor inválido. Insira um ID antes de atualizar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            try
            {
                using (MySqlConnection conexaoBanco = new ConexaoBDClass().Conectar())
                {
                    string atualizar = "update setores set nome = @nome where id = @id;";

                    MySqlCommand comando = new MySqlCommand(atualizar, conexaoBanco);

                    comando.Parameters.AddWithValue("@id", Id);
                    comando.Parameters.AddWithValue("@nome", Nome);
                    int resultado = comando.ExecuteNonQuery();
                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao atualizar setor ", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        //Método de Excluir Setor
        public bool ExcluirSetor()
        {
            try
            {

                if (id > 0)
                {
                    var resultado = MessageBox.Show("Você tem certeza que deseja excluir esse setor?", "Confirmar exclusão", MessageBoxButtons.YesNo);
                    if (resultado == DialogResult.Yes)
                    {
                        using (MySqlConnection conexaoBanco = new ConexaoBDClass().Conectar())
                        {
                            string excluir = "DELETE FROM setores WHERE id = @id;";
                            MySqlCommand comando = new MySqlCommand(excluir, conexaoBanco);

                            comando.Parameters.AddWithValue("@id", Id);

                            int resultadoConsulta = Convert.ToInt32(comando.ExecuteNonQuery());

                            if (resultadoConsulta > 0)
                            {
                                return true;
                            }
                            else
                            {
                                return false;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("O setor não foi deletado!");
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("Selecione um setor no datagrid para apagar!");
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao deletar setor", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        //Método de Listar Setores
        public DataTable ListarTodosSetores()
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBDClass().Conectar())
                {
                    string listar = "SELECT id, nome FROM setores";
                    MySqlCommand comando = new MySqlCommand(listar, conexao);
                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);
                    return tabela;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar setores: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        //Método de Listar Setores por Nome
        public DataTable ListarSetorPorNome(string nome)
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBDClass().Conectar())
                {
                    string consulta = "SELECT id, nome FROM setores WHERE nome LIKE @nome";
                    MySqlCommand comando = new MySqlCommand(consulta, conexao);

                    // Usando LIKE com % para buscar nomes parecidos
                    comando.Parameters.AddWithValue("@nome", "%" + nome + "%");

                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    return tabela;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar setor por nome: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

    }
}
