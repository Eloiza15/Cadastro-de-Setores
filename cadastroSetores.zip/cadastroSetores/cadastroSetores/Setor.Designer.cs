﻿namespace cadastroSetores
{
    partial class Setor
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNomeSetor = new Label();
            txtNomeSetor = new TextBox();
            dataGridSetores = new DataGridView();
            lblID = new Label();
            txtID = new TextBox();
            lblNome = new Label();
            txtNome = new TextBox();
            btnGravar = new Button();
            btnEditar = new Button();
            btnExcluir = new Button();
            btnListarT = new Button();
            btnListarN = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridSetores).BeginInit();
            SuspendLayout();
            // 
            // lblNomeSetor
            // 
            lblNomeSetor.AutoSize = true;
            lblNomeSetor.Location = new Point(29, 32);
            lblNomeSetor.Name = "lblNomeSetor";
            lblNomeSetor.Size = new Size(287, 29);
            lblNomeSetor.TabIndex = 0;
            lblNomeSetor.Text = "Digite o Nome do Setor:";
            // 
            // txtNomeSetor
            // 
            txtNomeSetor.Location = new Point(317, 29);
            txtNomeSetor.MaxLength = 200;
            txtNomeSetor.Name = "txtNomeSetor";
            txtNomeSetor.Size = new Size(391, 35);
            txtNomeSetor.TabIndex = 1;
            // 
            // dataGridSetores
            // 
            dataGridSetores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridSetores.Location = new Point(29, 87);
            dataGridSetores.Name = "dataGridSetores";
            dataGridSetores.RowHeadersVisible = false;
            dataGridSetores.RowHeadersWidth = 62;
            dataGridSetores.Size = new Size(679, 240);
            dataGridSetores.TabIndex = 2;
            dataGridSetores.CellDoubleClick += dataGridSetores_CellDoubleClick;
            // 
            // lblID
            // 
            lblID.AutoSize = true;
            lblID.Location = new Point(29, 352);
            lblID.Name = "lblID";
            lblID.Size = new Size(44, 29);
            lblID.TabIndex = 3;
            lblID.Text = "ID:";
            // 
            // txtID
            // 
            txtID.Location = new Point(134, 352);
            txtID.MaxLength = 200;
            txtID.Name = "txtID";
            txtID.Size = new Size(220, 35);
            txtID.TabIndex = 2;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(29, 411);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(86, 29);
            lblNome.TabIndex = 5;
            lblNome.Text = "Nome:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(134, 408);
            txtNome.MaxLength = 200;
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(574, 35);
            txtNome.TabIndex = 3;
            // 
            // btnGravar
            // 
            btnGravar.Location = new Point(29, 475);
            btnGravar.Name = "btnGravar";
            btnGravar.Size = new Size(179, 34);
            btnGravar.TabIndex = 4;
            btnGravar.Text = "Gravar";
            btnGravar.UseVisualStyleBackColor = true;
            btnGravar.Click += btnGravar_Click;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(277, 475);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(179, 34);
            btnEditar.TabIndex = 5;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(529, 475);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(179, 34);
            btnExcluir.TabIndex = 6;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            btnExcluir.Click += btnExcluir_Click;
            // 
            // btnListarT
            // 
            btnListarT.Location = new Point(161, 545);
            btnListarT.Name = "btnListarT";
            btnListarT.Size = new Size(168, 67);
            btnListarT.TabIndex = 7;
            btnListarT.Text = "Listar Todos Setores";
            btnListarT.UseVisualStyleBackColor = true;
            btnListarT.Click += btnListarT_Click;
            // 
            // btnListarN
            // 
            btnListarN.Location = new Point(420, 545);
            btnListarN.Name = "btnListarN";
            btnListarN.Size = new Size(168, 67);
            btnListarN.TabIndex = 8;
            btnListarN.Text = "Listar Setor Por Nome";
            btnListarN.UseVisualStyleBackColor = true;
            btnListarN.Click += btnListarN_Click;
            // 
            // Setor
            // 
            AutoScaleDimensions = new SizeF(15F, 29F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(741, 641);
            Controls.Add(btnListarN);
            Controls.Add(btnListarT);
            Controls.Add(btnExcluir);
            Controls.Add(btnEditar);
            Controls.Add(btnGravar);
            Controls.Add(txtNome);
            Controls.Add(lblNome);
            Controls.Add(txtID);
            Controls.Add(lblID);
            Controls.Add(dataGridSetores);
            Controls.Add(txtNomeSetor);
            Controls.Add(lblNomeSetor);
            Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(4, 3, 4, 3);
            Name = "Setor";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Setor";
            ((System.ComponentModel.ISupportInitialize)dataGridSetores).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNomeSetor;
        private TextBox txtNomeSetor;
        private DataGridView dataGridSetores;
        private Label lblID;
        private TextBox txtID;
        private Label lblNome;
        private TextBox txtNome;
        private Button btnGravar;
        private Button btnEditar;
        private Button btnExcluir;
        private Button btnListarT;
        private Button btnListarN;
    }
}
