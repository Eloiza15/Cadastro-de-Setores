using System.Data;

namespace cadastroSetores
{
    public partial class Setor : Form
    {
        public Setor()
        {
            InitializeComponent();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtNomeSetor.Text))
                {
                    MessageBox.Show("O campo Nome do Setor � obrigat�rio!", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                SetorClass setor = new SetorClass();
                setor.Nome = txtNomeSetor.Text;

                if (setor.InserirSetor())
                {
                    MessageBox.Show("Setor cadastrado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtNomeSetor.Clear();
                }
                else
                {
                    MessageBox.Show("Erro ao cadastrar o setor. Verifique os dados.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao tentar gravar o setor.\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtID.Text) || string.IsNullOrWhiteSpace(txtNome.Text))
                {
                    MessageBox.Show("Os campos ID e Nome s�o obrigat�rios!", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                SetorClass setor = new SetorClass();
                setor.Id = int.Parse(txtID.Text);
                setor.Nome = txtNome.Text;
                if (setor.AtualizarSetor())
                {
                    MessageBox.Show("Setor atualizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtID.Clear();
                    txtNomeSetor.Clear();
                }
                else
                {
                    MessageBox.Show("Erro ao atualizar o setor. Verifique os dados.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao tentar editar o setor.\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtID.Text))
                {
                    MessageBox.Show("O campo ID � obrigat�rio!", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                SetorClass setor = new SetorClass();
                setor.Id = int.Parse(txtID.Text);
                if (setor.ExcluirSetor())
                {
                    MessageBox.Show("Setor exclu�do com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtID.Clear();
                    txtNome.Clear();
                }
                else
                {
                    MessageBox.Show("Erro ao excluir o setor. Verifique os dados.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao tentar excluir o setor.\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void Setor_Load(object sender, EventArgs e)
        {
            SetorClass setor = new SetorClass();
            DataTable tabela = setor.ListarTodosSetores();

            if (tabela != null)
            {
                dataGridSetores.DataSource = tabela;
            }

            dataGridSetores.AllowUserToAddRows = false;
            dataGridSetores.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

           dataGridSetores.AutoResizeColumns();
           dataGridSetores.ClearSelection();
        }
    }
}
